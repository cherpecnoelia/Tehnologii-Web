export async function loadDashboard({ fetchImpl = fetch, render }) {
  // TODO: preluați toate sursele în paralel și randați stările de succes/eroare.
  // Păstrați randarea de loading prima, ca UI-ul să arate tranziția asincronă.
  render ({state: "loading"});



  try{
    const req1 = fetchImpl("/api/source1");
     const req2 = fetchImpl("/api/source2");
      const req3 = fetchImpl("/api/source3");


      const responses= await Promise.all([req1,req2,req3]);

      for (const res of responses){
        if(!res.ok){
          throw new Error('Eroare HTTP cu statusul: ${res.status}');
        }
      }

     const data1 = await responses[0].json();
    const data2 = await responses[1].json();
    const data3 = await responses[2].json();

    
    const successState = {
      state: "success",
      ...data1,
      ...data2,
      ...data3
    };
       
      render(successState);
      return successState;
  }
  catch(error){

    const errorState={
      state:"error", 
      error: error.message
    };

    render(errorState);
    return errorState;
  }
}






  

